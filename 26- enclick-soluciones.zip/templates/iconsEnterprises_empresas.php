		<div class="iconsEnterprises">
		<div class="titleMePersonal">
			<h3 id="clientes">Empresas con las que trabajamos</h3>
		</div>
		<div class="iconsContainer">
			<div class="icon_element">
				<p><img src="images/alianzas/amd.webp" alt="logo amd"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/benq.webp" alt="logo benq"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/cisco.webp" alt="logo cisco"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/intel.webp" alt="logo intel"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/kingstone.webp" alt="logo kingstone"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/lenovo.webp" alt="logo lenovo"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/linksys.webp" alt="logo linksys"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/microsoft.webp" alt="logo microsoft"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/mikrotik.webp" alt="logo mikrotik"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/nvidia.webp" alt="logo nvidia"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/oracle.webp" alt="logo oracle"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/samsung.webp" alt="logo samsung"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/sandisk.webp" alt="logo sandisk"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/symantec.webp" alt="logo symantec"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/hp.webp" alt="logo hp"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/toshiba.webp" alt="logo toshiba"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/tp-link.webp" alt="logo tp-link"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/dell.webp" alt="logo dell"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/ubiquiti.webp" alt="logo ubiquiti"></p>
			</div>
			<div class="icon_element">
				<p><img src="images/alianzas/wester-digital.webp" alt="logo wester digital"></p>
			</div>
		</div>
		</div>