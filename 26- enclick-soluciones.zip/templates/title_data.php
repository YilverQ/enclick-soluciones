<?php  
	$iconos = [ "fa-solid fa-building-columns",
				"fa-solid fa-user-group",
				"fa-solid fa-boxes-stacked",
				"fa-solid fa-location-dot",
				"fa-regular fa-message"];

	$blocks_titles = [	"¿Quiénes Somos?",
						"Nuestro equipo",
						"Servicios",
						"Zonas de coberturas",
						"Contacto"];
	//Array
	$blocks[0] = [$iconos[0], $blocks_titles[0]];
	$blocks[1] = [$iconos[1], $blocks_titles[1]];
	$blocks[2] = [$iconos[2], $blocks_titles[2]];
	$blocks[3] = [$iconos[3], $blocks_titles[3]];
	$blocks[4] = [$iconos[4], $blocks_titles[4]];
?>
		