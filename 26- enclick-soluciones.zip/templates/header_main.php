	<header id="inicio">
		<div class="infoHeader">
			<p class="nota">Dinos que servicio necesitas</p>
			<h1>Impulsa tu negocio gracias a la tecnología.</h1>
			<p class="textoInformativo">Enclick Soluciones, una empresa dedicada a solucionar  los problemas más frecuentes del área empresarial.</p>
			<a href="https://sumerlabs.com/catalogo/enclick-soluciones" target="_blank">Ver tienda</a>
		</div>
		<div class="contenedorImage">
			<img src="images/enclick-soluciones.gif" alt="Enclick Soluciones">
		</div>
	</header>