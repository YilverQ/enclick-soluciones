			<div class="iconsEnterprises">
				<div class="titleMePersonal">
					<h3 id="clientes">Métodos de pagos</h3>
				</div>
				<div class="iconsContainer">
					<div class="icon_element">
						<p><img src="../images/contacto/banesco.webp" alt="logo del banco banesco"></p>
					</div>
					<div class="icon_element">
						<p><img src="../images/contacto/tesoro.webp" alt="logo bando del tesoro"></p>
					</div>
					<div class="icon_element">
						<p><img src="../images/contacto/paypal.webp" alt="logo paypal"></p>
					</div>
					<div class="icon_element">
						<p><img src="../images/contacto/binance.webp" alt="logo binance"></p>
					</div>
					<div class="icon_element">
						<p><img src="../images/contacto/zelle.webp" alt="logo zelle"></p>
					</div>
					<div class="icon_element">
						<p><img src="../images/contacto/zinli.png" alt="logo zinli"></p>
					</div>
					<div class="icon_element">
						<p><img src="../images/contacto/efectivo.webp" alt="logo de pago en efectivo">
						</p>
					</div>
					<div class="icon_element">
						<p><img src="../images/contacto/movil.png" alt="logo de pago movil"></p>
					</div>
				</div>
			</div>