	<footer>
		<div class="footer">
			<div class="copyright">
				<p><i class="fa-regular fa-copyright"></i></p>
				<p>Enclick Soluciones 2022 C.A</p>
			</div>
			<div class="derechos">
				<ul>
					<li><a href="#" rel="nofollow">Politicas de privacidad</a></li>
					<li><a href="#" rel="nofollow">Políticas de Cookies</a></li>
					<li><a href="#" rel="nofollow">Aviso legal</a></li>
				</ul>
			</div>
		</div>
	</footer>